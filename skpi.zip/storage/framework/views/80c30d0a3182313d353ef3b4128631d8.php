

<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-10 px-6">
    <div class="bg-white p-6 rounded-lg shadow-xl">
        <h2 class="text-4xl font-bold mb-6">Edit Organisasi</h2>

        <form action="<?php echo e(route('organisasi.update', $organisasi->id_organisasi)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label for="id_organisasi" class="block text-sm font-semibold">ID Organisasi</label>
                <input type="text" name="id_organisasi" value="<?php echo e($organisasi->id_organisasi); ?>" class="w-full p-2 border rounded bg-gray-100 cursor-not-allowed" readonly>
            </div>

            <div class="mb-4">
                <label for="nama_organisasi" class="block text-sm font-semibold">Nama Organisasi</label>
                <input type="text" name="nama_organisasi" value="<?php echo e(old('nama_organisasi', $organisasi->nama_organisasi)); ?>" class="w-full p-2 border rounded <?php $__errorArgs = ['nama_organisasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <?php $__errorArgs = ['nama_organisasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/organisasi/edit.blade.php ENDPATH**/ ?>