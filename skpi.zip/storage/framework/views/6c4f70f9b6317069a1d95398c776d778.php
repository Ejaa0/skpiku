

<?php $__env->startSection('title', 'Data Organisasi WR III'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">

    <h1 class="text-2xl font-bold mb-4">Data Organisasi</h1>

    
    <form method="GET" action="<?php echo e(route('warek.dataorganisasi.index')); ?>" 
          class="mb-4 flex items-center space-x-2">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama organisasi"
               class="px-4 py-2 border rounded-lg w-full dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        
        <button type="submit" 
                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Cari
        </button>
    </form>

    <?php if(request('q')): ?>
        <p class="mb-2 text-gray-500 dark:text-gray-400">
            Hasil pencarian untuk: 
            <strong class="text-gray-700 dark:text-gray-200"><?php echo e(request('q')); ?></strong>
        </p>
    <?php endif; ?>

    
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg">
            <thead>
                <tr class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
                    <th class="px-4 py-2 text-left">ID</th>
                    <th class="px-4 py-2 text-left">Nama Organisasi</th>
                    
                    <th class="px-4 py-2 text-left">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $organisasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                        <td class="px-4 py-2"><?php echo e($org->id_organisasi); ?></td>
                        <td class="px-4 py-2"><?php echo e($org->nama_organisasi); ?></td>
                        

                        <td class="px-4 py-2 flex items-center space-x-2">

                            
                            <a href="<?php echo e(route('warek.dataorganisasi.show', $org->id_organisasi)); ?>"
                               class="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700">
                                Lihat
                            </a>

                            
                            <a href="<?php echo e(route('warek.dataorganisasi.edit', $org->id_organisasi)); ?>"
                               class="px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">
                                Edit
                            </a>

                            
                            <form action="<?php echo e(route('warek.dataorganisasi.destroy', $org->id_organisasi)); ?>" 
                                  method="POST"
                                  onsubmit="return confirm('Apakah yakin ingin menghapus organisasi ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700">
                                    Hapus
                                </button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                            Tidak ada data organisasi.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-4">
        <?php echo e($organisasis->appends(['q' => request('q')])->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/dataorganisasi/index.blade.php ENDPATH**/ ?>