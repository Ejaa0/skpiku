

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4 text-yellow-600">Edit Kegiatan</h2>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('kegiatan.update', $kegiatan->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block font-semibold">ID Kegiatan</label>
            <input type="text" name="id_kegiatan" value="<?php echo e(old('id_kegiatan', $kegiatan->id_kegiatan)); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Jenis Kegiatan</label>
            <select name="jenis_kegiatan" class="w-full border p-2 rounded" required>
                <option value="">-- Pilih Jenis Kegiatan --</option>
                <option value="Major" <?php echo e(old('jenis_kegiatan', $kegiatan->jenis_kegiatan) == 'Major' ? 'selected' : ''); ?>>Major</option>
                <option value="Reguler" <?php echo e(old('jenis_kegiatan', $kegiatan->jenis_kegiatan) == 'Reguler' ? 'selected' : ''); ?>>Reguler</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Nama Kegiatan</label>
            <input type="text" name="nama_kegiatan" value="<?php echo e(old('nama_kegiatan', $kegiatan->nama_kegiatan)); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Tanggal Kegiatan</label>
            <input type="date" name="tanggal_kegiatan" value="<?php echo e(old('tanggal_kegiatan', $kegiatan->tanggal_kegiatan)); ?>" class="w-full border p-2 rounded" required>
        </div>

        <div class="flex justify-between">
            <button type="submit" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Update</button>
            <a href="<?php echo e(route('kegiatan.index')); ?>" class="text-blue-500 hover:underline">← Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/kegiatan/edit.blade.php ENDPATH**/ ?>