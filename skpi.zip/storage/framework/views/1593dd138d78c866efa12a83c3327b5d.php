

<?php $__env->startSection('content'); ?>
<div class="flex flex-col">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold">Daftar Organisasi</h1>
        <a href="<?php echo e(route('organisasi.create')); ?>" class="px-5 py-2 bg-green-500 hover:bg-green-600 text-white rounded shadow">+ Tambah Organisasi</a>
    </div>

    <div class="overflow-x-auto shadow rounded-lg">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-200 dark:bg-gray-700">
                <tr>
                    <th class="px-4 py-3 text-left">ID</th>
                    <th class="px-4 py-3 text-left">Nama Organisasi</th>
                    <th class="px-4 py-3 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td class="px-4 py-2"><?php echo e($org->id); ?></td>
                    <td class="px-4 py-2"><?php echo e($org->nama_organisasi); ?></td>
                    <td class="px-4 py-2 flex gap-2">
                        <a href="<?php echo e(route('organisasi.edit', $org->id)); ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded">Edit</a>
                        <form action="<?php echo e(route('organisasi.destroy', $org->id)); ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="px-4 py-6 text-center text-gray-500 dark:text-gray-400">Belum ada organisasi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/tampilan_organisasi/organisasi.blade.php ENDPATH**/ ?>