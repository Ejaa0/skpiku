

<?php $__env->startSection('content'); ?>

<div class="max-w-5xl mx-auto mt-10 px-4 sm:px-6 lg:px-8">
    <h2 class="text-xl sm:text-2xl font-bold mb-6 text-yellow-600">
        🔍 Cari Mahasiswa untuk Kegiatan: <span class="text-gray-800"><?php echo e($kegiatan->nama_kegiatan); ?></span>
    </h2>

```

<form method="GET" action="<?php echo e(route('kegiatan.tambahMahasiswaForm', ['id' => $kegiatan->id])); ?>" class="mb-6">
    <input type="text" name="cari" value="<?php echo e(request('cari')); ?>" placeholder="Cari berdasarkan NIM atau Nama"
           class="w-full px-4 py-2 border border-yellow-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition">
</form>


<?php if($mahasiswa->isEmpty()): ?>
    <p class="text-gray-500">🙁 Tidak ada mahasiswa ditemukan.</p>
<?php else: ?>
    <div class="overflow-x-auto bg-white rounded-lg shadow ring-1 ring-gray-200">
        <table class="min-w-full divide-y divide-gray-200 text-sm">
            <thead class="bg-yellow-500 text-white uppercase tracking-wider">
                <tr>
                    <th class="px-6 py-3 text-left">NIM</th>
                    <th class="px-6 py-3 text-left">Nama</th>
                    <th class="px-6 py-3 text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-100">
                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-yellow-50 transition">
                        <td class="px-6 py-3 whitespace-nowrap"><?php echo e($mhs->nim); ?></td>
                        <td class="px-6 py-3 whitespace-nowrap"><?php echo e($mhs->nama); ?></td>
                        <td class="px-6 py-3 text-center">
                            <form method="POST" action="<?php echo e(route('kegiatan.storeMahasiswa', ['id' => $kegiatan->id])); ?>"
                                  onsubmit="return confirmTambahMahasiswa();">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="nim" value="<?php echo e($mhs->nim); ?>">
                                <button type="submit" class="inline-flex items-center text-green-600 hover:text-green-800 font-semibold transition">
                                    ➕ Tambah
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-6">
        <?php echo e($mahasiswa->appends(['cari' => request('cari')])->links()); ?>

    </div>
<?php endif; ?>


<div class="mt-8">
    <a href="<?php echo e(route('kegiatan.show', ['kegiatan' => $kegiatan->id])); ?>"
       class="inline-block text-sm bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
        ← Kembali ke Detail Kegiatan
    </a>
</div>
```

</div>

<script>
function confirmTambahMahasiswa() {
    return confirm('Apakah kamu akan menambahkan mahasiswa ini?');
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/kegiatan/tambah_mahasiswa.blade.php ENDPATH**/ ?>