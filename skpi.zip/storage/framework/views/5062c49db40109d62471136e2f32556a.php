

<?php $__env->startSection('content'); ?>

<h1 class="text-2xl font-bold mb-1">Kegiatan Mahasiswa</h1>
<p class="text-gray-600 mb-6">
    NIM: <span class="font-semibold"><?php echo e($nim); ?></span>
</p>


<div class="bg-white rounded-lg shadow p-6 mb-8">
    <h2 class="text-lg font-semibold mb-4">Daftar Kegiatan</h2>

    <table class="w-full text-sm border">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-4 py-2 w-16 text-center">No</th>
                <th class="border px-4 py-2 text-left">Nama Kegiatan</th>
                <th class="border px-4 py-2 text-left">Tanggal</th>
                <th class="border px-4 py-2 w-32 text-center">Poin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="border px-4 py-2 text-center"><?php echo e($loop->iteration); ?></td>
                    <td class="border px-4 py-2"><?php echo e($item->nama_kegiatan); ?></td>
                    <td class="border px-4 py-2">
                        <?php echo e(\Carbon\Carbon::parse($item->tanggal_kegiatan)->format('d M Y')); ?>

                    </td>
                    <td class="border px-4 py-2 text-center font-semibold text-green-600">
                        <?php echo e($item->poin); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center py-4 text-gray-500">
                        Belum mengikuti kegiatan
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<div class="bg-white rounded-lg shadow p-6">
    <h2 class="text-lg font-semibold mb-4">Poin Kegiatan</h2>

    <table class="w-full text-sm border">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-4 py-2 text-left">Keterangan</th>
                <th class="border px-4 py-2 w-32 text-center">Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="border px-4 py-2">Total Kegiatan Diikuti</td>
                <td class="border px-4 py-2 text-center">
                    <?php echo e($kegiatans->count()); ?>

                </td>
            </tr>
            <tr>
                <td class="border px-4 py-2 font-semibold">Total Poin</td>
                <td class="border px-4 py-2 text-center font-bold text-blue-600">
                    <?php echo e($totalPoin ?? 0); ?>

                </td>
            </tr>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_mahasiswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/tampilan_mahasiswa/kegiatan/index.blade.php ENDPATH**/ ?>