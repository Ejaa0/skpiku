

<?php $__env->startSection('title', 'Data Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6">
    <h2 class="text-3xl font-bold mb-6 text-gray-800 dark:text-gray-100">Data Organisasi</h2>

    <?php if(session('success')): ?>
        <div class="mb-6 p-4 bg-green-100 text-green-800 rounded shadow-sm">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Search Bar -->
    <div class="mb-6 flex justify-center">
        <form method="GET" action="<?php echo e(route('organisasi.self.index')); ?>" class="flex w-full max-w-lg">
            <input 
                type="text" 
                name="search" 
                placeholder="Cari nama organisasi..." 
                value="<?php echo e($search ?? ''); ?>"
                class="flex-1 px-4 py-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-400 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
            >
            <button 
                type="submit" 
                class="px-4 py-2 bg-blue-500 text-white font-semibold rounded-r-lg hover:bg-blue-600 transition"
            >
                Cari
            </button>
        </form>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto shadow-md rounded-lg">
        <table class="w-full table-auto border-collapse bg-white dark:bg-gray-800">
            <thead class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 uppercase text-sm">
                <tr>
                    <th class="px-6 py-3 border-b">ID</th>
                    <th class="px-6 py-3 border-b">Nama Organisasi</th>
                    <th class="px-6 py-3 border-b">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 dark:text-gray-300">
                <?php $__empty_1 = true; $__currentLoopData = $organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                    <td class="px-6 py-4 border-b"><?php echo e($org->id_organisasi); ?></td>
                    <td class="px-6 py-4 border-b"><?php echo e($org->nama_organisasi); ?></td>
                    <td class="px-6 py-4 border-b flex gap-2">
                        <a href="<?php echo e(route('organisasi.self.show', $org->id_organisasi)); ?>" 
                           class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition">Lihat</a>
                        
                        <form action="<?php echo e(route('organisasi.self.destroy', $org->id_organisasi)); ?>" method="POST" onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center py-4 text-gray-500 dark:text-gray-400">Tidak ada data organisasi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/tampilan_organisasi/organisasi/index.blade.php ENDPATH**/ ?>