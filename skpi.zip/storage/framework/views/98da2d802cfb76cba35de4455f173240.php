

<?php $__env->startSection('title', 'Tambah Anggota Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md max-w-2xl mx-auto">
    <h1 class="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">➕ Tambah Anggota</h1>

    <form action="<?php echo e(route('warek.dataorganisasi.anggota.store', $id_organisasi)); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <div>
            <label>NIM Mahasiswa</label>
            <input type="text" name="nim" value="<?php echo e(old('nim')); ?>" required>
        </div>
        <div>
            <label>Nama Mahasiswa</label>
            <input type="text" name="nama" value="<?php echo e(old('nama')); ?>" required>
        </div>
        <div>
            <label>Jabatan</label>
            <input type="text" name="jabatan" value="<?php echo e(old('jabatan')); ?>" required>
        </div>
        <div>
            <label>Status Keanggotaan</label>
            <select name="status_keanggotaan" required>
                <option value="">-- Pilih Status --</option>
                <option value="Aktif">Aktif</option>
                <option value="Tidak Aktif">Tidak Aktif</option>
            </select>
        </div>
        <button type="submit">Simpan</button>
        <a href="<?php echo e(route('warek.dataorganisasi.show', $id_organisasi)); ?>">Kembali</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/dataorganisasi/tambah_anggota.blade.php ENDPATH**/ ?>