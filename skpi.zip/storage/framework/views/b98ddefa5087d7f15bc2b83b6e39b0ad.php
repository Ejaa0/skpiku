

<?php $__env->startSection('content'); ?>

<div class="p-6 bg-white text-gray-900 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold mb-4">Edit Kegiatan</h1>

    <form action="<?php echo e(route('warek.datakegiatan.update', $kegiatan->id)); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="jenis_kegiatan" class="block mb-1 font-semibold">Jenis Kegiatan</label>
            <select name="jenis_kegiatan" id="jenis_kegiatan" class="w-full p-2 rounded border border-gray-300 bg-white">
                <option value="Reguler" <?php echo e($kegiatan->jenis_kegiatan == 'Reguler' ? 'selected' : ''); ?>>Reguler</option>
                <option value="Non-Reguler" <?php echo e($kegiatan->jenis_kegiatan == 'Non-Reguler' ? 'selected' : ''); ?>>Non-Reguler</option>
            </select>
            <?php $__errorArgs = ['jenis_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="nama_kegiatan" class="block mb-1 font-semibold">Nama Kegiatan</label>
            <input type="text" name="nama_kegiatan" id="nama_kegiatan" value="<?php echo e(old('nama_kegiatan', $kegiatan->nama_kegiatan)); ?>" class="w-full p-2 rounded border border-gray-300 bg-white">
            <?php $__errorArgs = ['nama_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div>
            <label for="tanggal_kegiatan" class="block mb-1 font-semibold">Tanggal Kegiatan</label>
            <input type="date" name="tanggal_kegiatan" id="tanggal_kegiatan" value="<?php echo e(old('tanggal_kegiatan', $kegiatan->tanggal_kegiatan)); ?>" class="w-full p-2 rounded border border-gray-300 bg-white">
            <?php $__errorArgs = ['tanggal_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex items-center space-x-2">
            <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-white font-semibold">Simpan Perubahan</button>
            <a href="<?php echo e(route('warek.datakegiatan.index')); ?>" class="px-4 py-2 bg-gray-400 hover:bg-gray-500 rounded text-white font-semibold">Kembali</a>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/datakegiatan/edit.blade.php ENDPATH**/ ?>