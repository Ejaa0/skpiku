<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Dashboard Mahasiswa - SKPI UNAI</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        /* Animasi Fade */
        .fade-in {
            animation: fadeIn 0.5s ease-in-out forwards;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>

<body class="bg-gray-100 min-h-screen flex">

    <!-- Sidebar -->
    <aside id="sidebar"
        class="bg-indigo-900 text-indigo-100 w-64 flex-shrink-0 flex flex-col fixed md:static inset-y-0 
               left-0 z-30 transform -translate-x-full md:translate-x-0 transition-all duration-300">

        <!-- Header -->
        <div class="flex items-center justify-between px-6 py-4 border-b border-indigo-700">
            <h1 class="text-xl font-bold tracking-wide">SKPI UNAI</h1>

            <button id="closeSidebarBtn" class="md:hidden">
                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Menu -->
        <nav class="flex flex-col mt-4 px-4 space-y-2 flex-grow">

            <a href="/mahasiswa/dashboard"
                class="py-3 px-4 rounded-lg hover:bg-indigo-700 flex items-center gap-3 font-semibold
                       transition-all duration-200 bg-indigo-800">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 12h18M3 6h18M3 18h18"/>
                </svg>
                <span>Dashboard</span>
            </a>

            <a href="/profile"
                class="py-3 px-4 rounded-lg hover:bg-indigo-700 transition flex items-center gap-3 font-semibold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M5.121 17.804A4 4 0 019 15h6a4 4 0 013.879 2.804M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                </svg>
                Profil
            </a>

            <a href="/poin/riwayat"
                class="py-3 px-4 rounded-lg hover:bg-indigo-700 transition flex items-center gap-3 font-semibold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path d="M8 16h8m-4-12v12m-6 4h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
                Riwayat Poin
            </a>

            <a href="/skpi/mahasiswa"
                class="py-3 px-4 rounded-lg hover:bg-indigo-700 transition flex items-center gap-3 font-semibold">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path d="M9 12h6m-6 4h6M7 4h10a2 2 0 012 2v12a2 2 0 01-2 2H7a2 2 0 01-2-2V6a2 2 0 012-2z"/>
                </svg>
                Lihat SKPI
            </a>

            <!-- Logout -->
            <button id="logoutBtn"
                class="mt-auto py-3 px-4 rounded-lg hover:bg-red-600 bg-red-500 transition flex items-center gap-3 font-semibold text-left mb-4">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M17 16l4-4m0 0l-4-4m4 4H7"/>
                </svg>
                Logout
            </button>
        </nav>
    </aside>

    <!-- Main Content -->
    <div class="flex flex-col flex-grow ml-0 md:ml-64 transition-all duration-300">

        <!-- Navbar Mobile -->
        <header class="bg-white shadow-md md:hidden flex items-center justify-between px-4 py-3 sticky top-0 z-20">
            <button id="openSidebarBtn">
                <svg class="w-6 h-6 text-indigo-700" fill="none" stroke="currentColor" stroke-width="2"
                     viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>

            <h1 class="text-indigo-700 font-bold text-lg">Dashboard Mahasiswa</h1>
            <div></div>
        </header>

        <!-- Content -->
        <main class="p-8 bg-gray-100 fade-in">

            <!-- Welcome -->
            <h2 class="text-3xl font-bold mb-6 text-indigo-900">🎓 Selamat Datang, Mahasiswa!</h2>

            <!-- Cards -->
            <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

                <!-- Card -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl 
                            transform hover:-translate-y-1 transition-all duration-300">
                    <img src="https://source.unsplash.com/400x200/?education,university" 
                         class="w-full h-48 object-cover" />

                    <div class="p-5">
                        <h3 class="text-xl font-semibold text-indigo-800 mb-2">Pelatihan SKPI</h3>
                        <p class="text-gray-600 text-sm mb-4">
                            Pelatihan SKPI akan diadakan 10 Juni 2025. Daftar sebelum 5 Juni!
                        </p>
                        <a href="#" class="text-indigo-600 hover:text-indigo-800 text-sm font-semibold">
                            Baca Selengkapnya →
                        </a>
                    </div>
                </div>

            </section>

        </main>

        <!-- Footer -->
        <footer class="text-center py-6 text-indigo-700 font-semibold">
            © 2025 Sistem SKPI UNAI • Dashboard Mahasiswa
        </footer>
    </div>

    <!-- Modal Logout -->
    <div id="modalBg"
        class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 items-center justify-center">
        <div class="bg-white rounded-lg shadow-lg max-w-sm w-full p-6 text-center">

            <h3 class="text-lg font-semibold mb-4">Anda yakin ingin keluar?</h3>

            <div class="flex justify-center gap-4">
                <button id="confirmLogout"
                    class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition">
                    Ya
                </button>
                <button id="cancelLogout"
                    class="bg-gray-300 px-6 py-2 rounded-lg hover:bg-gray-400 transition">
                    Tidak
                </button>
            </div>

        </div>
    </div>

    <!-- Script -->
    <script>
        const sidebar = document.getElementById('sidebar');
        const openBtn = document.getElementById('openSidebarBtn');
        const closeBtn = document.getElementById('closeSidebarBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const modalBg = document.getElementById('modalBg');
        const confirmLogout = document.getElementById('confirmLogout');
        const cancelLogout = document.getElementById('cancelLogout');

        openBtn.addEventListener('click', () => sidebar.classList.remove('-translate-x-full'));
        closeBtn.addEventListener('click', () => sidebar.classList.add('-translate-x-full'));

        logoutBtn.addEventListener('click', () => modalBg.classList.remove('hidden'));
        cancelLogout.addEventListener('click', () => modalBg.classList.add('hidden'));

        confirmLogout.addEventListener('click', () => window.location.href = '/login/mahasiswa');
        modalBg.addEventListener('click', (e) => { if (e.target === modalBg) modalBg.classList.add('hidden'); });
    </script>

</body>
</html>
<?php /**PATH C:\skpi\laravel-12\resources\views/mahasiswa/dashboard.blade.php ENDPATH**/ ?>