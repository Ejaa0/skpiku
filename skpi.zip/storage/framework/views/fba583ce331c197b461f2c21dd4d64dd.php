

<?php $__env->startSection('content'); ?>

<div class="space-y-6">

    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="p-6 rounded-2xl shadow-lg bg-gradient-to-br from-blue-600 to-blue-500 
                    text-white transform hover:scale-[1.03] transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-semibold opacity-90">Total Kegiatan</h2>
                    <p class="text-5xl font-extrabold mt-3 drop-shadow-md"><?php echo e($totalKegiatan); ?></p>
                </div>
                <div class="bg-white/20 p-3 rounded-xl backdrop-blur-md">
                    <span class="material-icons text-white text-4xl">event</span>
                </div>
            </div>
        </div>

        <div class="p-6 rounded-2xl shadow-lg bg-gradient-to-br from-green-600 to-green-500 
                    text-white transform hover:scale-[1.03] transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-lg font-semibold opacity-90">Total Organisasi</h2>
                    <p class="text-5xl font-extrabold mt-3 drop-shadow-md"><?php echo e($totalOrganisasi); ?></p>
                </div>
                <div class="bg-white/20 p-3 rounded-xl backdrop-blur-md">
                    <span class="material-icons text-white text-4xl">groups</span>
                </div>
            </div>
        </div>
    </div>

    
    <div class="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-lg">
        <h2 class="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-200">📅 Kegiatan Terbaru</h2>

        <?php if($latestKegiatan->isEmpty()): ?>
            <p class="text-gray-500 dark:text-gray-400 italic">Belum ada kegiatan yang dibuat.</p>
        <?php else: ?>
            <div class="space-y-4">
                <?php $__currentLoopData = $latestKegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 rounded-xl bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 
                                dark:hover:bg-gray-600 transition flex justify-between items-center">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100">
                                <?php echo e($item->nama_kegiatan); ?>

                            </h3>
                            <p class="text-sm text-gray-600 dark:text-gray-300">
                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_kegiatan)->format('d M Y')); ?>

                            </p>
                        </div>
                        <span class="material-icons text-blue-500 text-3xl">event_note</span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/tampilan_organisasi/dashboard_organisasi.blade.php ENDPATH**/ ?>