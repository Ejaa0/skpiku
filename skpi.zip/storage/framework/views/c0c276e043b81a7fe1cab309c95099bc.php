

<?php $__env->startSection('title', 'Tambah Mahasiswa ke Kegiatan'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">🔍 Cari Mahasiswa untuk Kegiatan: <?php echo e($kegiatan->nama_kegiatan); ?></h1>

    <!-- Form Search -->
    <form action="<?php echo e(route('warek.tambahanggota.kegiatan.create', $kegiatan->id)); ?>" method="GET" class="mb-4">
        <input type="text" name="search" placeholder="Cari berdasarkan NIM atau Nama"
               value="<?php echo e(request('search')); ?>"
               class="w-full p-2 rounded border border-gray-300">
    </form>

    <!-- Pesan sukses / error -->
    <?php if(session('success')): ?>
        <div class="mb-4 p-2 bg-green-200 text-green-800 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="mb-4 p-2 bg-red-200 text-red-800 rounded">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="mb-4 p-2 bg-red-200 text-red-800 rounded">
            <ul class="list-disc pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Tabel Mahasiswa -->
    <div class="bg-white p-6 rounded shadow">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr>
                    <th class="border-b p-2">NIM</th>
                    <th class="border-b p-2">Nama</th>
                    <th class="border-b p-2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $search = request('search');
                    $filteredMahasiswa = $mahasiswa->filter(function($m) use ($search) {
                        return !$search || str_contains($m->nim, $search) || str_contains(strtolower($m->nama), strtolower($search));
                    });
                ?>

                <?php $__empty_1 = true; $__currentLoopData = $filteredMahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="border-b p-2"><?php echo e($m->nim); ?></td>
                        <td class="border-b p-2"><?php echo e($m->nama); ?></td>
                        <td class="border-b p-2">
                            <?php if($kegiatan->mahasiswa->contains('nim', $m->nim)): ?>
                                <span class="text-green-600 font-semibold">✔ Sudah ditambahkan</span>
                            <?php else: ?>
                                <form action="<?php echo e(route('warek.tambahanggota.kegiatan.store', $kegiatan->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="nim" value="<?php echo e($m->nim); ?>">
                                    <button type="submit" 
                                            class="px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                                            onclick="return confirm('Yakin ingin menambahkan mahasiswa ini ke kegiatan?')">
                                        ➕ Tambah
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="p-2">Tidak ada mahasiswa ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <a href="<?php echo e(route('warek.tambahanggota.kegiatan.show', $kegiatan->id)); ?>"
       class="inline-block mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600">
       ← Kembali ke Detail Kegiatan
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/datakegiatan/tambah_mahasiswa.blade.php ENDPATH**/ ?>