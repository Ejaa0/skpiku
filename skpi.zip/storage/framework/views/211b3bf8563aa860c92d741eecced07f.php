

<?php $__env->startSection('content'); ?>
<div class="text-gray-900 dark:text-gray-100">
    <h1 class="text-3xl font-bold mb-6">Penentuan Poin Mahasiswa</h1>

    <div class="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow-md mb-6">
        <p class="text-gray-700 dark:text-gray-200">
            Halaman ini digunakan untuk menentukan poin mahasiswa berdasarkan keikutsertaan mereka
            dalam kegiatan dan organisasi.
        </p>
    </div>

    <div class="flex justify-end mb-4">
        <a href="<?php echo e(route('penentuan_poin.create')); ?>"
            class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Tambah Poin</a>
    </div>

    <?php if(session('success')): ?>
        <div class="mb-4 text-green-600 dark:text-green-400"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 dark:border-gray-600 rounded-lg overflow-hidden">
            <thead class="bg-gray-200 dark:bg-gray-800">
                <tr>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">No</th>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">Keterangan</th>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">Poin</th>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $poin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b border-gray-300 dark:border-gray-600">
                        <td class="px-4 py-2"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-2"><?php echo e($item->keterangan); ?></td>
                        <td class="px-4 py-2"><?php echo e($item->poin); ?></td>
                        <td class="px-4 py-2 flex gap-2">
                            <a href="<?php echo e(route('penentuan_poin.edit', $item->id)); ?>"
                                class="px-2 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600">Edit</a>
                            <form action="<?php echo e(route('penentuan_poin.destroy', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="px-2 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                                    onclick="return confirm('Yakin ingin dihapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-4 py-4 text-center text-gray-500 dark:text-gray-300">
                            Belum ada data penentuan poin.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($poin->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/penentuan_poin/index.blade.php ENDPATH**/ ?>