

<?php $__env->startSection('title', 'Detail Kegiatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-50 min-h-screen">
    <!-- Judul -->
    <h1 class="text-3xl font-extrabold mb-6 text-gray-800"><?php echo e($kegiatan->nama_kegiatan); ?></h1>

    <!-- Info Kegiatan -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <!-- ID Kegiatan -->
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <p class="text-gray-500 font-semibold">ID Kegiatan</p>
            <p class="text-gray-800"><?php echo e($kegiatan->id_kegiatan); ?></p>
        </div>

        <!-- Jenis Kegiatan -->
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <p class="text-gray-500 font-semibold">Jenis Kegiatan</p>
            <?php if(strtolower($kegiatan->jenis_kegiatan) === 'major'): ?>
                <span class="text-white bg-blue-600 px-2 py-1 rounded-full text-sm font-semibold">Major</span>
            <?php elseif(strtolower($kegiatan->jenis_kegiatan) === 'reguler'): ?>
                <span class="text-white bg-green-600 px-2 py-1 rounded-full text-sm font-semibold">Reguler</span>
            <?php else: ?>
                <span class="text-gray-400 text-sm">-</span>
            <?php endif; ?>
        </div>

        <!-- Nama Kegiatan -->
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <p class="text-gray-500 font-semibold">Nama Kegiatan</p>
            <p class="text-gray-800"><?php echo e($kegiatan->nama_kegiatan); ?></p>
        </div>

        <!-- Tanggal Kegiatan -->
        <div class="bg-white p-4 rounded-lg shadow-sm border">
            <p class="text-gray-500 font-semibold">Tanggal Kegiatan</p>
            <p class="text-gray-800"><?php echo e($kegiatan->tanggal_kegiatan); ?></p>
        </div>
    </div>

    <!-- Tombol Tambah Mahasiswa -->
    <a href="<?php echo e(route('kegiatan-self.addMahasiswa', $kegiatan->id)); ?>" 
       class="inline-block bg-blue-600 text-white font-semibold px-6 py-2 rounded-lg shadow hover:bg-blue-700 transition duration-200 mb-6">
        Tambah Mahasiswa
    </a>

    <!-- Daftar Mahasiswa -->
    <h2 class="text-2xl font-bold mb-3 text-gray-700">Daftar Mahasiswa</h2>
    <div class="overflow-x-auto bg-white rounded-lg shadow border">
        <table class="w-full text-left border-collapse">
            <thead class="bg-gray-100">
                <tr>
                    <th class="border px-4 py-3 text-gray-600 uppercase text-sm">NIM</th>
                    <th class="border px-4 py-3 text-gray-600 uppercase text-sm">Nama</th>
                    <th class="border px-4 py-3 text-gray-600 uppercase text-sm">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kegiatan->detailMahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition duration-150">
                        <td class="border px-4 py-2"><?php echo e($detail->mahasiswa->nim ?? '-'); ?></td>
                        <td class="border px-4 py-2"><?php echo e($detail->mahasiswa->nama ?? '-'); ?></td>
                        <td class="border px-4 py-2">
                            <form action="<?php echo e(route('kegiatan-self.destroyMahasiswa', [$kegiatan->id, $detail->mahasiswa->nim])); ?>" method="POST" onsubmit="return confirm('Yakin ingin hapus?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="bg-red-600 text-white px-3 py-1 rounded shadow hover:bg-red-700 transition duration-200">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center py-4 text-gray-500">
                            Belum ada mahasiswa terdaftar.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Kembali ke daftar -->
    <a href="<?php echo e(route('kegiatan-self.index')); ?>" class="mt-6 inline-block text-blue-600 font-medium hover:underline">
        &larr; Kembali ke daftar kegiatan
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/tampilan_kegiatan/kegiatan/show.blade.php ENDPATH**/ ?>