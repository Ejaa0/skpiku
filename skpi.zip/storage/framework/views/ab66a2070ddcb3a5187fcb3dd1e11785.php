

<?php $__env->startSection('content'); ?>
<div class="max-w-lg mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4 text-blue-600">Edit Mahasiswa</h2>

    <form method="POST" action="<?php echo e(route('mahasiswa.update', $mahasiswa)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label class="block font-semibold">Nama Mahasiswa</label>
            <input type="text" name="nama" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->nama); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">NIM</label>
            <input type="text" name="nim" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->nim); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Tempat Lahir</label>
            <input type="text" name="temp_lahir" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->temp_lahir); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Tanggal Lahir</label>
            <input type="date" name="tgl_lahir" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->tgl_lahir); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Jenis Kelamin</label>
            <select name="sex" class="w-full border p-2 rounded">
                <option value="L" <?php echo e($mahasiswa->sex == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                <option value="P" <?php echo e($mahasiswa->sex == 'P' ? 'selected' : ''); ?>>Perempuan</option>
            </select>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Agama</label>
            <input type="text" name="agama" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->agama); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Hobi</label>
            <input type="text" name="hobi" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->hobi); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Angkatan</label>
            <input type="text" name="angkatan" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->angkatan); ?>" required>
        </div>

        <div class="mb-4">
            <label class="block font-semibold">Email</label>
            <input type="email" name="email" class="w-full border p-2 rounded" value="<?php echo e($mahasiswa->email); ?>" required>
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Perbarui</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>