

<?php $__env->startSection('title', 'Edit Anggota Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold text-green-600 mb-6">
        ✏️ Edit Anggota: <?php echo e($anggota->nama); ?> (<?php echo e($anggota->nim); ?>)
    </h2>

    <form action="<?php echo e(route('organisasi.self.update_anggota', [$id_organisasi, $anggota->nim])); ?>" method="POST" class="space-y-5 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
        <?php echo csrf_field(); ?>

        <!-- NIM -->
        <div>
            <label class="block text-gray-700 dark:text-gray-200 font-semibold mb-1">NIM</label>
            <input type="text" value="<?php echo e($anggota->nim); ?>" disabled class="w-full px-4 py-2 border rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
        </div>

        <!-- Nama -->
        <div>
            <label class="block text-gray-700 dark:text-gray-200 font-semibold mb-1">Nama</label>
            <input type="text" value="<?php echo e($anggota->nama); ?>" disabled class="w-full px-4 py-2 border rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
        </div>

        <!-- Jabatan / Divisi -->
        <div>
            <label class="block text-gray-700 dark:text-gray-200 font-semibold mb-1">Jabatan / Divisi</label>
            <select name="jabatan" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:text-gray-200">
                <?php
                    $roles = [
                        'Ketua', 'Wakil Ketua', 'Sekretaris', 'Bendahara', 'Anggota',
                        'Divisi Akademik', 'Divisi Acara', 'Divisi Olahraga', 'Divisi Multimedia', 
                        'Divisi Humas', 'Divisi Logistik'
                    ];
                ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role); ?>" <?php echo e(old('jabatan', $anggota->jabatan) === $role ? 'selected' : ''); ?>>
                        <?php echo e($role); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Status Keanggotaan -->
        <div>
            <label class="block text-gray-700 dark:text-gray-200 font-semibold mb-1">Status Keanggotaan</label>
            <select name="status_keanggotaan" class="w-full px-4 py-2 border rounded-lg dark:bg-gray-700 dark:text-gray-200">
                <option value="aktif" <?php echo e(old('status_keanggotaan', $anggota->status_keanggotaan) === 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="nonaktif" <?php echo e(old('status_keanggotaan', $anggota->status_keanggotaan) === 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
            </select>
        </div>

        <!-- Tombol -->
        <div class="flex gap-2">
            <button type="submit" class="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition">
                💾 Simpan Perubahan
            </button>
            <a href="<?php echo e(route('organisasi.self.show', $id_organisasi)); ?>" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition">
                ← Kembali
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/tampilan_organisasi/organisasi/edit.blade.php ENDPATH**/ ?>