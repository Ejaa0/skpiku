

<?php $__env->startSection('title', 'Cari Poin Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-bold mb-4">Cari Poin Mahasiswa</h1>

    
    <form method="GET" action="<?php echo e(route('warek.poin')); ?>" class="mb-4 flex items-center space-x-2">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari NIM atau Nama"
               class="px-4 py-2 border rounded-lg w-full dark:bg-gray-700 dark:text-gray-200">
        <button type="submit" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600">Cari</button>
    </form>

    <?php if(request('q')): ?>
        <?php if($poinMahasiswa->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <thead>
                        <tr class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
                            <th class="px-4 py-2 text-left">NIM</th>
                            <th class="px-4 py-2 text-left">Nama</th>
                            <th class="px-4 py-2 text-left">Poin</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $poinMahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b dark:border-gray-700">
                            <td class="px-4 py-2"><?php echo e($poin->nim); ?></td>
                            <td class="px-4 py-2"><?php echo e($poin->nama); ?></td>
                            <td class="px-4 py-2"><?php echo e($poin->poin); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="mt-4">
                    <?php echo e($poinMahasiswa->appends(['q' => request('q')])->links()); ?>

                </div>
            </div>
        <?php else: ?>
            <p class="text-gray-500 dark:text-gray-400">Data tidak ditemukan untuk "<?php echo e(request('q')); ?>".</p>
        <?php endif; ?>
    <?php else: ?>
        <p class="text-gray-500 dark:text-gray-400">Masukkan NIM atau Nama untuk mencari poin mahasiswa.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/poin/index.blade.php ENDPATH**/ ?>