

<?php $__env->startSection('title', 'Edit Kegiatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-100 min-h-screen">
    <h1 class="text-2xl font-bold text-gray-800 mb-6">Edit Kegiatan</h1>

    <form action="<?php echo e(url('kegiatan-self/'.$kegiatan->id.'/update')); ?>" method="POST" class="bg-white p-6 rounded shadow space-y-4">
        <?php echo csrf_field(); ?>
        <!-- jangan pakai <?php echo method_field('PUT'); ?>, route pakai POST -->

        <!-- Nama Kegiatan -->
        <div>
            <label class="text-gray-800 font-semibold">Nama Kegiatan</label>
            <input type="text" name="nama_kegiatan" 
                   value="<?php echo e(old('nama_kegiatan', $kegiatan->nama_kegiatan)); ?>" 
                   class="w-full px-3 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                   required>
            <?php $__errorArgs = ['nama_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Jenis Kegiatan -->
        <div>
            <label class="text-gray-800 font-semibold">Jenis Kegiatan</label>
            <select name="jenis_kegiatan" 
                    class="w-full px-3 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">-- Pilih Jenis Kegiatan --</option>
                <option value="Major" <?php echo e(old('jenis_kegiatan', $kegiatan->jenis_kegiatan) == 'Major' ? 'selected' : ''); ?>>Major</option>
                <option value="Reguler" <?php echo e(old('jenis_kegiatan', $kegiatan->jenis_kegiatan) == 'Reguler' ? 'selected' : ''); ?>>Reguler</option>
            </select>
            <?php $__errorArgs = ['jenis_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Tanggal Kegiatan -->
        <div>
            <label class="text-gray-800 font-semibold">Tanggal Kegiatan</label>
            <input type="date" name="tanggal_kegiatan" 
                   value="<?php echo e(old('tanggal_kegiatan', $kegiatan->tanggal_kegiatan)); ?>" 
                   class="w-full px-3 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                   required>
            <?php $__errorArgs = ['tanggal_kegiatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Deskripsi -->
        <div>
            <label class="text-gray-800 font-semibold">Deskripsi</label>
            <textarea name="deskripsi" rows="4" 
                      class="w-full px-3 py-2 rounded border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('deskripsi', $kegiatan->deskripsi)); ?></textarea>
            <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex space-x-4">
            <button type="submit" class="bg-blue-500 px-4 py-2 rounded hover:bg-blue-600 text-white">Update</button>
            <a href="<?php echo e(route('kegiatan-self.index')); ?>" class="bg-gray-400 px-4 py-2 rounded hover:bg-gray-500 text-white">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/tampilan_kegiatan/kegiatan/edit.blade.php ENDPATH**/ ?>