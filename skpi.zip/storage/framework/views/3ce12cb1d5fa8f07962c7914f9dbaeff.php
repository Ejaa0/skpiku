

<?php $__env->startSection('title', 'Tambah Anggota Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-md">
    <h1 class="text-2xl font-bold mb-4 text-gray-800 dark:text-gray-100">➕ Tambah Anggota</h1>

    
    <form action="<?php echo e(route('warek.dataorganisasi.anggota.store', $organisasi->id_organisasi)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="id_organisasi" value="<?php echo e($organisasi->id_organisasi); ?>">

        
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300">Pilih Mahasiswa</label>
            <select name="nim" class="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:text-gray-200">
                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m->nim); ?>"><?php echo e($m->nim); ?> - <?php echo e($m->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300">Jabatan</label>

            <select name="jabatan" id="jabatanSelect"
                class="border px-3 py-2 w-full rounded dark:bg-gray-700 dark:text-gray-200" required>
                <option value="">-- Pilih Jabatan --</option>
                <option value="ketua">Ketua</option>
                <option value="wakil">Wakil</option>
                <option value="bendahara">Bendahara</option>
                <option value="divisi acara">Divisi Acara</option>
                <option value="divisi olahraga">Divisi Olahraga</option>
                <option value="divisi multimedia">Divisi Multimedia</option>
                <option value="divisi logistik">Divisi Logistik</option>
                <option value="divisi humas">Divisi Humas</option>
                <option value="lainnya">➕ Lainnya</option>
            </select>

            
            <input 
                type="text" 
                name="jabatan_custom" 
                id="jabatanCustom" 
                class="mt-2 hidden w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-gray-200" 
                placeholder="Masukkan jabatan/divisi baru..."
            >
        </div>

        
        <div class="mb-4">
            <label class="block text-gray-700 dark:text-gray-300">Status Keanggotaan</label>
            <select name="status_keanggotaan" class="w-full px-3 py-2 border rounded-lg dark:bg-gray-700 dark:text-gray-200">
                <option value="aktif">Aktif</option>
                <option value="nonaktif">Nonaktif</option>
            </select>
        </div>

        <button type="submit" class="bg-green-500 hover:bg-green-400 text-white px-4 py-2 rounded-lg">
            Tambah Anggota
        </button>
    </form>
</div>


<script>
    document.getElementById('jabatanSelect').addEventListener('change', function () {
        let customInput = document.getElementById('jabatanCustom');
        if (this.value === 'lainnya') {
            customInput.classList.remove('hidden');
            customInput.required = true;
        } else {
            customInput.classList.add('hidden');
            customInput.required = false;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/dataorganisasi/create.blade.php ENDPATH**/ ?>