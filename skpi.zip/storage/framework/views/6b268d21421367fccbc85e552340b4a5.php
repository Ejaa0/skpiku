

<?php $__env->startSection('title', 'Tambah Organisasi'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-bold mb-4">Tambah Organisasi</h2>

    <?php if($errors->any()): ?>
        <div class="mb-4 p-3 bg-red-200 text-red-800 rounded">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>- <?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('organisasi.self.store')); ?>" method="POST" class="space-y-4 max-w-lg">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block mb-1 font-semibold">ID Organisasi</label>
            <input type="number" name="id_organisasi" value="<?php echo e(old('id_organisasi')); ?>"
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:border-gray-600" required>
        </div>
        <div>
            <label class="block mb-1 font-semibold">Nama Organisasi</label>
            <input type="text" name="nama_organisasi" value="<?php echo e(old('nama_organisasi')); ?>"
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:border-gray-600" required>
        </div>
        <div class="flex gap-2">
            <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600">Simpan</button>
            <a href="<?php echo e(route('organisasi.self.index')); ?>"
                class="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600">Batal</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_organisasi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/tampilan_organisasi/organisasi/create.blade.php ENDPATH**/ ?>