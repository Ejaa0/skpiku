

<?php $__env->startSection('title', 'Daftar Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 bg-gray-50 dark:bg-gray-800 rounded-2xl shadow-lg">
    <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Daftar Organisasi</h1>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white dark:bg-gray-700 rounded-lg overflow-hidden">
            <thead class="bg-gray-200 dark:bg-gray-600">
                <tr>
                    <th class="py-3 px-4 text-left text-gray-800 dark:text-white">ID Organisasi</th>
                    <th class="py-3 px-4 text-left text-gray-800 dark:text-white">Nama Organisasi</th>
                    <th class="py-3 px-4 text-left text-gray-800 dark:text-white">Jumlah Anggota</th>
                    <th class="py-3 px-4 text-left text-gray-800 dark:text-white">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $organisasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600">
                    <td class="py-2 px-4 text-gray-800 dark:text-white"><?php echo e($org->id_organisasi); ?></td>
                    <td class="py-2 px-4 text-gray-800 dark:text-white"><?php echo e($org->nama_organisasi); ?></td>
                    <td class="py-2 px-4 text-gray-800 dark:text-white"><?php echo e($org->detailOrganisasiMahasiswa->count()); ?></td>
                    <td class="py-2 px-4">
                        <a href="<?php echo e(route('detail_organisasi_mahasiswa.index', ['id_organisasi' => $org->id_organisasi])); ?>" 
                           class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Lihat Anggota</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center py-4 text-gray-500 dark:text-gray-300">
                        Belum ada organisasi.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_warek_utama', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\skpi\laravel-12\resources\views/warek/tampilan_organisasi/index.blade.php ENDPATH**/ ?>