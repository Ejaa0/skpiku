

<?php $__env->startSection('content'); ?>
<div class="text-gray-900 dark:text-gray-100">
    <h1 class="text-3xl font-bold mb-6">Kriteria Poin Mahasiswa</h1>

    <div class="bg-white dark:bg-gray-700 p-6 rounded-2xl shadow-md mb-6">
        <p class="text-gray-700 dark:text-gray-200">
            Halaman ini menampilkan kriteria poin mahasiswa berdasarkan keikutsertaan mereka
            dalam kegiatan dan organisasi.
        </p>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-300 dark:border-gray-600 rounded-lg overflow-hidden">
            <thead class="bg-gray-200 dark:bg-gray-800">
                <tr>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">No</th>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">Keterangan</th>
                    <th class="px-4 py-2 text-left border-b border-gray-300 dark:border-gray-600">Poin</th>
                </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-700">
                <?php $__empty_1 = true; $__currentLoopData = $poin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b border-gray-300 dark:border-gray-600">
                        <td class="px-4 py-2"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-2"><?php echo e($item->keterangan); ?></td>
                        <td class="px-4 py-2"><?php echo e($item->poin); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="px-4 py-4 text-center text-gray-500 dark:text-gray-300">
                            Belum ada data kriteria poin.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($poin->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_mahasiswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/tampilan_mahasiswa/kriteria_poin.blade.php ENDPATH**/ ?>