

<?php $__env->startSection('title', 'Edit Anggota Organisasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="p-6 max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold text-green-600 mb-6">
        Edit Anggota: <?php echo e($anggota->nim); ?>

    </h2>

    <form action="<?php echo e(route('organisasi.self.update_anggota', [$organisasi->id_organisasi, $anggota->nim])); ?>" method="POST" class="bg-white shadow rounded p-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- NIM -->
        <div class="mb-4">
            <label for="nim" class="block text-gray-700 font-medium mb-1">NIM</label>
            <input type="text" name="nim" id="nim" value="<?php echo e($anggota->nim); ?>" class="w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-300" readonly>
        </div>

        <!-- Nama -->
        <div class="mb-4">
            <label for="nama" class="block text-gray-700 font-medium mb-1">Nama</label>
            <input type="text" name="nama" id="nama" value="<?php echo e($anggota->nama); ?>" class="w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-300" readonly>
        </div>

        <!-- Jabatan -->
        <div class="mb-4">
            <label for="jabatan" class="block text-gray-700 font-medium mb-1">Jabatan</label>
            <select name="jabatan" id="jabatan" class="border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-green-400">
                <?php
                    $jabatanOptions = [
                        'Ketua', 'Wakil', 'Sekretaris', 'Bendahara',
                        'Divisi Akademik', 'Divisi Acara', 'Divisi Olahraga',
                        'Divisi Multimedia', 'Divisi Logistik', 'Divisi Humas', 'Divisi Kerohanian'
                    ];
                ?>
                <?php $__currentLoopData = $jabatanOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($jabatan); ?>" <?php echo e($anggota->jabatan == $jabatan ? 'selected' : ''); ?>><?php echo e($jabatan); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Status Keanggotaan -->
        <div class="mb-4">
            <label for="status_keanggotaan" class="block text-gray-700 font-medium mb-1">Status Keanggotaan</label>
            <select name="status_keanggotaan" id="status_keanggotaan" class="w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-green-300">
                <option value="aktif" <?php echo e($anggota->status_keanggotaan == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="tidak aktif" <?php echo e($anggota->status_keanggotaan == 'tidak aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
            </select>
        </div>

        <div class="flex justify-end">
            <a href="<?php echo e(route('organisasi.self.show', $organisasi->id_organisasi)); ?>" class="bg-gray-500 text-white px-4 py-2 rounded mr-2">Batal</a>
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Rhesa Panjaitan\Downloads\laravel-12\resources\views/tampilan_organisasi/organisasi/edit_anggota.blade.php ENDPATH**/ ?>