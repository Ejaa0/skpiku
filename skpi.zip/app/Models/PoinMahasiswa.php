<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
        
class PoinMahasiswa extends Model
{
    protected $fillable = ['nim', 'nama', 'poin'];
}
