<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PoinMahasiswa;
use App\Models\Mahasiswa;
use App\Models\DetailKegiatanMahasiswa;

use Illuminate\Support\Facades\DB;

class PoinMahasiswaController extends Controller
{
    /**
     * Menampilkan daftar poin mahasiswa.
     */
    public function index(Request $request)
    {
        // Update poin semua mahasiswa dulu sebelum ambil data untuk tampil
        $nims = DB::table('mahasiswas')->pluck('nim');

        foreach ($nims as $nim) {
            $this->updatePoinMahasiswa($nim);
        }

        $search = $request->input('search');

        // Ambil semua data poin mahasiswa dan filter jika ada pencarian
        $mahasiswas = PoinMahasiswa::when($search, function ($query, $search) {
                return $query->where('nama', 'like', "%$search%")
                             ->orWhere('nim', 'like', "%$search%");
            })
            ->orderByDesc('poin') // urutkan dari poin tertinggi
            ->get()
            ->map(function ($mhs) {
                // Tambahkan alias supaya sesuai dengan blade
                $mhs->total_poin = $mhs->poin;
                return $mhs;
            });

        return view('poin.index', compact('mahasiswas', 'search'));
    }

    /**
     * Hitung & update poin mahasiswa berdasarkan nim.
     */
    private function updatePoinMahasiswa($nim)
    {
        $nama = DB::table('mahasiswas')->where('nim', $nim)->value('nama');

        if (!$nama) {
            $nama = DB::table('detail_kegiatan_mahasiswa')->where('mahasiswa_nim', $nim)->value('nama')
                ?? DB::table('detail_organisasi_mahasiswa')->where('nim', $nim)->value('nama');
        }

        if (!$nama) return false;

        $jumlahKegiatan = DB::table('detail_kegiatan_mahasiswa')
            ->where('mahasiswa_nim', $nim)
            ->count();

        $jumlahOrganisasi = DB::table('detail_organisasi_mahasiswa')
            ->where('nim', $nim)
            ->count();

        // Default poin: 100 per kegiatan, 150 per organisasi
        $totalPoin = ($jumlahKegiatan * 100) + ($jumlahOrganisasi * 250);

        PoinMahasiswa::updateOrCreate(
            ['nim' => $nim],
            ['nama' => $nama, 'poin' => $totalPoin]
        );

        return true;
    }

    /**
     * Menampilkan detail poin mahasiswa.
     */
    public function show($nim)
{
    $mahasiswa = Mahasiswa::findOrFail($nim);

    // Ambil kegiatan mahasiswa beserta nama dari tabel kegiatan
    $kegiatans = DetailKegiatanMahasiswa::with('kegiatan')
        ->where('mahasiswa_nim', $nim)
        ->get()
        ->map(function($item) {
            $item->nama_kegiatan = $item->kegiatan->nama_kegiatan ?? 'Kegiatan';
            $item->poin_kegiatan = 100;
            return $item;
        });

    $organisasis = DB::table('detail_organisasi_mahasiswa')
        ->where('nim', $nim)
        ->get()
        ->map(function ($item) {
            $item->nama_organisasi = $item->nama_organisasi ?? 'Organisasi';
            $item->poin_organisasi = 250;
            return $item;
        });

    $totalPoin = $kegiatans->sum('poin_kegiatan') + $organisasis->sum('poin_organisasi');

    $mahasiswa->poin = $totalPoin;

    return view('poin.show', [
        'poin' => $mahasiswa,
        'kegiatans' => $kegiatans,
        'organisasis' => $organisasis,
    ]);
}

    /**
     * Simpan atau update poin mahasiswa berdasarkan nim.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nim' => 'required|string|max:20',
        ], [
            'nim.required' => 'Pilih mahasiswa terlebih dahulu.',
            'nim.string'   => 'Format NIM tidak valid.',
            'nim.max'      => 'NIM maksimal 20 karakter.',
        ]);

        $nim = $request->nim;

        $nama = DB::table('mahasiswas')->where('nim', $nim)->value('nama');

        if (!$nama) {
            $nama = DB::table('detail_kegiatan_mahasiswa')->where('mahasiswa_nim', $nim)->value('nama')
                ?? DB::table('detail_organisasi_mahasiswa')->where('nim', $nim)->value('nama');
        }

        if (!$nama) {
            return back()->with('error', 'Data mahasiswa tidak ditemukan.');
        }

        $jumlahKegiatan = DB::table('detail_kegiatan_mahasiswa')->where('mahasiswa_nim', $nim)->count();
        $jumlahOrganisasi = DB::table('detail_organisasi_mahasiswa')->where('nim', $nim)->count();

        $totalPoin = ($jumlahKegiatan * 100) + ($jumlahOrganisasi * 250);

        PoinMahasiswa::updateOrCreate(
            ['nim' => $nim],
            ['nama' => $nama, 'poin' => $totalPoin]
        );

        return redirect()->route('poin.index')->with('success', 'Poin mahasiswa berhasil disimpan.');
    }

    /**
     * Hapus data poin mahasiswa.
     */
    public function destroy($nim)
    {
        $poin = PoinMahasiswa::findOrFail($nim);
        $poin->delete();

        return redirect()->route('poin.index')->with('success', 'Data berhasil dihapus.');
    }

    /**
     * Ambil data poin terbaru untuk API / JSON.
     */
    public function getAllLatestPoin()
    {
        $data = PoinMahasiswa::select('nim', 'poin')->get();
        return response()->json($data);
    }

    /**
     * Export data ke CSV.
     */
    public function export()
    {
        $mahasiswas = PoinMahasiswa::orderByDesc('poin')->get();

        $filename = 'poin_mahasiswa_' . date('Ymd_His') . '.csv';

        $headers = [
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        ];

        $columns = ['NIM', 'Nama', 'Poin'];

        $callback = function() use ($mahasiswas, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);

            foreach ($mahasiswas as $mhs) {
                fputcsv($file, [$mhs->nim, $mhs->nama, $mhs->poin]);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
